# FMCG Distribution Execution Collection - Data Catalog

**Collection:** FMCG Distribution Execution  
**Tool slug:** `fmcg-distribution-execution`

Purpose: Evidence specialist for operational drivers that can explain commercial performance: inventory, availability, coverage, returns, damage/expiry, promotions and service fulfilment.

## Datasets

- `distributor_inventory.csv` - monthly inventory flow, closing stock, inventory days and ageing.
- `stock_availability.csv` - SKU/distributor stockout days, availability and estimated lost sales.
- `outlet_coverage.csv` - planned, visited and productive outlet coverage with estimated missed sales.
- `sales_returns.csv` - returns by distributor, SKU and reason.
- `damage_expiry.csv` - distributor stock damage and expiry loss.
- `promotion_execution.csv` - promotion rollout, participating outlets, uplift, scheme economics and execution gap.
- `service_fulfilment.csv` - distributor fill rate, OTIF, cancellation and delivery time.

## Usage note

Estimated lost/missed sales fields are analytical evidence, not proof of perfect causality. They should be compared with observed commercial movement and corroborating evidence before root-cause conclusions are stated.
