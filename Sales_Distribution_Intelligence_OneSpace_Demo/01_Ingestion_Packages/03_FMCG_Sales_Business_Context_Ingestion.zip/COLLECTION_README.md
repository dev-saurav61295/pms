# FMCG Sales Business Context Collection

**Tool slug:** `fmcg-sales-business-context`

This collection contains operating guidance, monthly business reviews, distributor notes, field observations, communications and exception notes. It provides qualitative context and corroborating evidence. It must not override structured facts unless the evidence explicitly establishes a correction. Conflicts should be surfaced, not silently resolved.
