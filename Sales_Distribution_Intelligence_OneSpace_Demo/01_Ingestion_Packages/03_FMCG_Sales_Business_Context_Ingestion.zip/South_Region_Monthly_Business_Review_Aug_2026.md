# South Region Monthly Business Review - August 2026

South continues to perform above its early-year run rate. The March step-up was linked to festival demand, broader outlet coverage, strong beverage/snack activation and high product availability. The region has largely retained the expanded outlet base after the festival period.
