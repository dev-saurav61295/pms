# Aurevia Sales & Distribution Operating Guidelines

## Purpose
These guidelines define the operating interpretation used in monthly Sales & Distribution reviews.

## Commercial review
- Primary sales represent company sell-in to distributors.
- Secondary sales represent distributor sell-through to outlets and are the preferred measure of market movement.
- Strong primary sales should not be treated as healthy demand when secondary sales are weak and distributor inventory is rising.

## Inventory and availability
- Distributor inventory is normally expected to remain within approximately 25-40 days depending on category and market.
- Availability below 90% requires investigation; availability below 80% is a material service risk.
- Rising inventory days together with weak secondary sales should trigger a replenishment and ageing review.

## Outlet execution
- Planned outlet coverage and productive outlet coverage should be reviewed separately.
- High call volume does not by itself indicate good execution; productive calls, strike rate and order value should also be assessed.

## Service
- Target fill rate: 95% or better.
- Target OTIF: 92% or better.
- Deteriorating service can be a leading risk even when current sales remain strong.

## Promotions
Promotion evaluation must separate execution quality from commercial effectiveness. A well-executed scheme with weak uplift should not be classified as an execution failure.
