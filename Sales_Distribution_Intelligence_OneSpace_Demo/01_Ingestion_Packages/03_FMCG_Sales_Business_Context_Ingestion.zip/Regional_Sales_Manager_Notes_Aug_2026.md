# Regional Sales Manager Notes - August 2026

## East
Kolkata availability and Bhubaneswar coverage need separate interventions; they should not be treated as one regional demand problem.

## Guwahati - Horizon Distribution Services
Several priority outlets reported recurring delivery delays during the second half of August. These complaints were raised despite the monthly service dashboard remaining broadly within normal range. The team should inspect late-month and priority-outlet service rather than relying only on the aggregate monthly metric.

## West
Pune sales remain strong, but service deterioration is becoming visible in distributor conversations.
