# Aurevia Promotion Execution Guidelines

A promotion review should evaluate four separate questions:
1. Was the promotion made available to the intended outlets?
2. Did participating outlets execute the scheme correctly?
3. Did participating outlets show incremental sales versus baseline?
4. Was the incremental margin sufficient relative to scheme cost?

Execution percentage and sales uplift must not be treated as interchangeable metrics. Low execution with strong uplift among participating outlets indicates rollout opportunity. High execution with weak uplift indicates the scheme mechanics, proposition, targeting or economics require review.
