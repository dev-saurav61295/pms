# Distributor Review Notes - August 2026

## MetroLink Consumer Trade - Kolkata
The distributor repeatedly escalated shortages on FizzUp Cola 750ml, FizzUp Cola 1.5L, HydraGo Lemon 500ml and HydraGo Electrolyte 1L. Outlet demand was reported as normal, but replenishment was insufficient for high-velocity packs.

## Utkal Consumer Distribution - Bhubaneswar
Warehouse build-up is visible, particularly across Nutrition & Staples. The distributor requested lower near-term replenishment on slower-moving items until outlet movement catches up.

## BlueRiver Wholesale - Bhubaneswar
The branch highlighted poor route adherence and missed calls in the main territory during August. Inventory availability was not cited as the primary constraint.
