# Exception and Escalation Notes - August 2026

1. East beverage availability: priority escalation for MetroLink Consumer Trade.
2. Bhubaneswar outlet coverage: route recovery required for BlueRiver Wholesale.
3. East CrunchCo Monsoon Combo: rollout below plan despite positive response in participating outlets.
4. Pune fulfilment: monitor fill rate, OTIF and cancellations despite strong sales.
5. Horizon Distribution Services: investigate priority-outlet delivery complaints because qualitative reports do not fully align with monthly aggregate service metrics.
