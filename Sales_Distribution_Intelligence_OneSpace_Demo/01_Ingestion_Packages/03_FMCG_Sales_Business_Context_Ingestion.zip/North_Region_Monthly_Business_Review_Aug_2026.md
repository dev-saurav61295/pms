# North Region Monthly Business Review - August 2026

North remained broadly stable but did not receive a meaningful lift from the PureGlow Glow Days activity. Field reports indicate the activation was present across most planned outlets. The commercial team is reviewing whether the offer was sufficiently differentiated and whether the scheme economics justify extension.
