# FMCG Commercial Performance Collection - Data Catalog

**Collection:** FMCG Commercial Performance  
**Tool slug:** `fmcg-commercial-performance`

Purpose: Evidence specialist for commercial outcomes, trends, targets, hierarchy drilldowns, primary/secondary sales, product contribution, distributor contribution, and sales-force performance.

## Datasets

- `region_master.csv` - region hierarchy and regional ownership.
- `branch_master.csv` - branch-to-region hierarchy.
- `distributor_master.csv` - distributor master and branch/region mapping.
- `salesperson_master.csv` - salesperson, territory, distributor, branch, and region mapping.
- `outlet_master.csv` - outlet/channel/territory/distributor/salesperson mapping.
- `product_master.csv` - category, brand, SKU, pack and standard case price.
- `primary_sales.csv` - monthly manufacturer-to-distributor sell-in by distributor and SKU.
- `secondary_sales.csv` - monthly distributor-to-outlet sell-through by outlet, salesperson and SKU.
- `salesperson_performance.csv` - monthly salesperson target, sales, calls, productive calls, strike rate and AOV.
- `sales_targets.csv` - monthly targets for region, branch and distributor levels.

## Core relationships

`Region -> Branch -> Distributor -> Outlet`  
`Branch -> Salesperson -> Territory -> Outlet`  
`Category -> Brand -> SKU`  
Primary and secondary sales share distributor, geography and SKU keys for comparison.

## Reporting period

December 2025 through August 2026. August 2026 is the latest complete reporting month.
